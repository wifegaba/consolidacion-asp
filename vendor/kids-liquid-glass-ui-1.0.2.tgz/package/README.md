# @kids/liquid-glass-ui

Dashboard React reutilizable con tarjetas Liquid Glass, dock con magnificación y ventanas animadas.

## Uso como librería local

1. Copia la carpeta `liquid-glass-ui` dentro de `packages/` en tu proyecto.
2. Instala la carpeta local:

```bash
pnpm add ./packages/liquid-glass-ui
```

3. Importa el componente y sus estilos:

```tsx
import { LiquidGlassDashboard } from "@kids/liquid-glass-ui";
import "@kids/liquid-glass-ui/styles.css";

export default function Page() {
  return <LiquidGlassDashboard />;
}
```

## Compilar la librería

Si modificas sus fuentes:

```bash
cd packages/liquid-glass-ui
pnpm install
pnpm build
```

La carpeta `dist/` contiene el JavaScript ESM, los tipos TypeScript y el CSS que debes conservar al copiar el paquete.

## Transición premium entre contenidos

`LiquidGlassSweepTransition` permite conservar una vista mientras una ventana
se expande y, cuando cambia a `active`, barre el contenido anterior hacia la
derecha mientras el nuevo entra suavemente desde la izquierda.

```tsx
import {
  LiquidGlassSweepTransition,
  type LiquidGlassSweepState,
} from "@kids/liquid-glass-ui";

export function Detail({ open }: { open: boolean }) {
  const state: LiquidGlassSweepState = open ? "active" : "idle";

  return (
    <section className="detail-shell">
      <LiquidGlassSweepTransition
        state={state}
        outgoing={<div className="detail-preview">Vista previa</div>}
        incoming={<div className="detail-content">Contenido completo</div>}
        outgoingDuration={560}
        incomingDuration={680}
        incomingDelay={180}
      />
    </section>
  );
}
```

Estados disponibles:

- `idle`: muestra el contenido saliente.
- `active`: ejecuta el barrido premium y muestra el contenido entrante.
- `closing`: realiza la secuencia inversa.

La animación utiliza exclusivamente `transform` y `opacity`, incluye soporte
para `prefers-reduced-motion` y permite ajustar distancias y tiempos sin
modificar el CSS del proyecto consumidor.
