# @kids/liquid-glass-ui

Dashboard React reutilizable con tarjetas Liquid Glass, dock con magnificación y ventanas animadas.

## Uso como librería local

1. Copia la carpeta `liquid-glass-ui` dentro de `packages/` en tu proyecto.
2. Instala la carpeta local:

```bash
pnpm add ./packages/liquid-glass-ui
```

3. Importa el componente y sus estilos:

```tsx
import { LiquidGlassDashboard } from "@kids/liquid-glass-ui";
import "@kids/liquid-glass-ui/styles.css";

export default function Page() {
  return <LiquidGlassDashboard />;
}
```

## Compilar la librería

Si modificas sus fuentes:

```bash
cd packages/liquid-glass-ui
pnpm install
pnpm build
```

La carpeta `dist/` contiene el JavaScript ESM, los tipos TypeScript y el CSS que debes conservar al copiar el paquete.
